#include<avr/io.h>
#include <stdlib.h>
#include <stdio.h>

#include "ff.h"
#include "diskio.h"

int main(void)
{
	static FATFS FATFS_Obj;
FIL fil_obj;

// SD card initialization.
disk_initialize(0);

// File system initialization.
f_mount(0, &FATFS_Obj);

// Create text file "file.txt".
f_open(&fil_obj, "/file.txt", FA_CREATE_NEW);

// File to be open for writing.
f_open(&fil_obj, "/file.txt", FA_WRITE);

// Writing into file.
f_printf(&fil_obj, "SD Card test");

	// Close file.
f_close(&fil_obj);
}
