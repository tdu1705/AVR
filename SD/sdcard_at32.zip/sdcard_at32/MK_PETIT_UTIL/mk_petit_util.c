/*
 * mk_petit_util.c
 *
 *  Created on: 2011-12-12
 *       Autor: Miros�aw Karda�
 */
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include <avr/pgmspace.h>

#include "../PetitFS/diskio.h"
#include "../PetitFS/pff.h"

#include "mk_petit_util.h"


uint16_t SD_BUF_SIZE;
uint8_t *sd_buf;


uint8_t  mk_petit_init( void * petit_buf, uint16_t sd_buf_size, uint8_t spi2x ) {
	uint8_t res;

	SPI_DIR 	|= CS | MOSI | SCK;
	SPI_PORT 	|= CS | MISO;
	SPCR 		|= (1<<SPE)|(1<<MSTR);

	sd_buf = petit_buf;
	SD_BUF_SIZE = sd_buf_size;

	if( spi2x ) SPCR |= (1<<SPI2X);

#if USE_SD_PWR == 1
	sd_pwr(0);
	_delay_ms(50);
	sd_pwr(1);
	_delay_ms(50);
#endif

	res = disk_initialize();

	return res;
}






#if USE_FILE_APPEND == 1
/*
 *   FILE APPEND - funkcja dodaje dane na ko�cu pliku
 *
 *   *wfs - wska�nik do obiektu FATFS
 *   *fname - wska�nik do nazwy pliku
 *   *txt - tekst, kt�ry ma by� dodany na ko�cu
 *
 */
int mk_pf_file_append(FATFS *wfs, char * fname, char *txt) {

	uint16_t 	i, buf_free=0, len_txt = strlen(txt);
	uint32_t 	sektor=0, tmr = 65000;
	uint8_t 	res=0;
	WORD 		rb;
	uint8_t 	*bf = sd_buf;

#if USE_SD_PWR == 1
	sd_pwr(0);		// od��czamy zasilanie karty
	_delay_ms(100);
	sd_pwr(1);		// pod��czamy zasilanie karty
#endif

	res = mk_sd_init();	// inicjalizacja karty
	if( res ) return res;

	res = mk_mount(wfs);  // montowanie volumenu
	if( res ) return res;

	res = mk_open(fname);	// otwarcie pliku
	if( res ) return res;

	while(1) {
		// odczyt danych z liku do bufora
		res = 1;
		pf_read(sd_buf, 512, &rb);
		if( rb<512 ) break;
		// sprawdzamy czy wyst�pi� w sektorze "pusty znak"
		for(i=0; i<512; i++) if( bf[i] == FILE_BLANK_CHAR ) break;
		// je�li nie wyst�pi� to powr�t do pocz�tku p�tli while(1)
		if(512==i) { sektor++; continue; }
		// obliczenie wolnego miejsca w sektorze
		buf_free = 512 - i;
		// por�wnanie ilo�� wolnego miejsca z d�ugo�ci� tekstu do zapisu
		if(buf_free>=len_txt) {
			// je�li zapisywany tekst zmie�ci si� w bie��cym sektorze
			// kopiujemy tekst do bufora w wolne miejsce
			memcpy(&bf[i], txt, len_txt);
			// ustawiamy wska�nik do pliku na pocz�tek tego sektora
			tmr=1000; res=100;
			while( pf_lseek(sektor*512UL) && tmr-- );
			if(!tmr) break;
			// dokonujemy zapisu ca�ego bufora do sektora
			res=5;
			pf_write(&bf[0], 512, &rb);
			if(rb<512) {
				break;	// je�li zapisano mniej bajt�w - KONIEC pliku
			}

			res = 0; // zapis zako�czony powodzeniem

		} else { // je�li zapisywany tekst trafi mi�dzy sektory
			// **** zapis pocz�tku tekstu w ko�c�wce sektora
			memcpy(&bf[i], txt, buf_free);

			tmr=1000; res=100;
			while( pf_lseek(sektor*512UL) && tmr-- );
			if(!tmr) break;

			res=5;
			pf_write(&bf[0], 512, &rb);
			if(rb<512) break;
			pf_write(0, 0, &rb);

			// **** zapis reszty tekstu w kolejnym sektorze
			res = mk_sd_init();
			if( res ) return res;

			res = mk_mount(wfs);
			if( res ) return res;

			res = mk_open(fname);
			if( res ) return res;

			tmr=1000; res=100;
			while( pf_lseek((sektor+1)*512UL) && tmr-- );
			if(!tmr) break;

			pf_read(sd_buf, SD_BUF_SIZE, &rb);

			memcpy(bf, &txt[buf_free], strlen(&txt[buf_free]));

			tmr=1000; res=100;
			while( pf_lseek((sektor+1)*512UL) && tmr-- );
			if(!tmr) break;
			pf_write(&bf[0], 512, &rb);

			pf_write(0, 0, &rb);

			res = mk_sd_init();
			if( res ) return res;

		}
		break;	// przerywamy p�tl� niesko�czon�
	}	// koniec while(1)

	disk_initialize();

	return res;
}

//int mk_pf_file_append_P(FATFS *wfs, char * fname, const char *txt) {
	
#endif



#if USE_SD_PWR == 1
/*
 * 		FUNKCJA Programowego w��czania i wy��czania zasilania do karty
 * 		pami�ci MMC/SD w zestawach uruchomieniowych ATB od wersji 1.02
 *
 * 		sd_pwr(1) - w��czenie zasilania
 * 		sd_pwr(0) - wy��czenie zasilania
 */
void sd_pwr( uint8_t OnOff ) {
	SD_PWR_DIR |= SD_PWR_PIN;
	if(OnOff) {
		SD_ON;
		SPCR |= (1<<SPE);
		_delay_ms(50);
		disk_initialize();
	} else {
		SD_OFF;
		SPCR &= ~(1<<SPE);
		PORTB &= ~(SCK|MISO|MOSI);
		_delay_ms(300);	// czas potrzebny na roz�adowanie kondensator�w (min 250ms)
	}
}
#endif
